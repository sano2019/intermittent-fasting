import type { Profile, FastingPattern } from "./types";
import { loadLang, t } from "./i18n";

const patterns: { key: FastingPattern; label: string; note: string }[] = [
  { key: "16:8", label: "16:8", note: "8h eating / 16h fast" },
  { key: "5:2", label: "5:2", note: "5 days normal / 2 light" },
  { key: "OMAD", label: "OMAD", note: "One meal a day" },
  { key: "custom", label: "Custom", note: "Your own rhythm" },
];

export function renderProfile(app: HTMLElement) {
  app.innerHTML = `
    <header>
      <div class="header-row">
        <h1>${t("profile.title")}</h1>
        <a href="#/" class="header-link" id="back-link">${t("nav.back")}</a>
      </div>
      <p>${t("profile.subtitle")}</p>
    </header>

    <section class="card">
      <h2>${t("profile.title")}</h2>
      <form id="profile-form">
        <label class="field-label">${t("profile.language")}</label>
      <select id="lang-select" class="text-input">
        <option value="en">English</option>
        <option value="sv">Svenska</option>
        <option value="nl">Nederlands</option>
        <option value="vi">Tiếng Việt</option>
      </select>

      <label class="field-label" for="user-name">${t("profile.name")}</label>
        <input id="user-name" type="text" value="You" class="text-input" />

        <label class="field-label">${t("profile.pattern")}</label>
        <div class="pattern-grid">
          ${patterns.map((p) => `<button type="button" class="pattern-btn" data-pattern="${p.key}" aria-label="${p.label}">${p.label}<span class="small note-inline">${p.note}</span></button>`).join("")}
        </div>

        <div class="time-row">
          <div>
            <label class="field-label" for="start-time">${t("profile.start")}</label>
            <input id="start-time" type="time" value="08:00" class="text-input" />
          </div>
          <div>
            <label class="field-label" for="end-time">${t("profile.end")}</label>
            <input id="end-time" type="time" value="16:00" class="text-input" />
          </div>
        </div>

        <button type="submit" class="primary-btn" onclick="this.form.dispatchEvent(new Event('submit', {bubbles:true}))">${t("profile.save")}</button>
        <span id="save-confirm" class="small" style="margin-left:8px;color:#7fbf7f;opacity:0;transition:opacity 0.3s;display:inline-block;">${t("profile.saved")}</span>
      </form>
    </section>

    <section class="card">
      <h2>${t("profile.account")}</h2>
      <p class="small">${t("profile.local")}</p>
    </section>
  `;

  // Load existing profile into form if present
  const adapter = (window as any).adapter;
  if (adapter) {
    adapter.loadProfile().then((p: Profile | null) => {
      if (!p) return;
      const input = app.querySelector<HTMLInputElement>("#user-name")!;
      input.value = p.name || "You";
      const selected = app.querySelector(`.pattern-btn[data-pattern="${p.pattern}"]`);
      if (selected) selected.classList.add("selected");
      const langSelect = app.querySelector<HTMLSelectElement>("#lang-select");
      if (langSelect && p.lang) langSelect.value = p.lang;
      const start = app.querySelector<HTMLInputElement>("#start-time")!;
      if (p.startTime) start.value = p.startTime;
      const end = app.querySelector<HTMLInputElement>("#end-time")!;
      if (p.endTime) end.value = p.endTime;
    });
  }

  // Pattern selection
  app.querySelectorAll(".pattern-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      app.querySelectorAll(".pattern-btn").forEach((b) => b.classList.remove("selected"));
      btn.classList.add("selected");
    });
  });

  // Save
  const form = app.querySelector<HTMLFormElement>("#profile-form")!;
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const selected = app.querySelector(".pattern-btn.selected") as HTMLElement;
    const profile: Profile = {
      id: "local-user-1",
      name: (app.querySelector<HTMLInputElement>("#user-name")!.value) || "You",
      pattern: (selected?.getAttribute("data-pattern") as FastingPattern) ?? "custom",
      startTime: app.querySelector<HTMLInputElement>("#start-time")!.value,
      endTime: app.querySelector<HTMLInputElement>("#end-time")!.value,
      lang: app.querySelector<HTMLSelectElement>("#lang-select")!.value,
      createdAt: new Date().toISOString(),
    };
    if (adapter) adapter.saveProfile(profile);

    loadLang(profile.lang as any);
    renderProfile(app); // language loads immediately (before splash)
    const confirm = document.querySelector("#splash-confirm") || app.querySelector("#save-confirm") as HTMLElement;
    if (confirm) { confirm.style.opacity = "1"; setTimeout(() => confirm.style.opacity = "0", 2000); }
  });

  // Back link returns to main app view
  const backLink = app.querySelector("#back-link");
  if (backLink) {
    backLink.addEventListener("click", (e) => {
      e.preventDefault();
      window.location.hash = "/";
      window.location.reload();
    });
  }
}
